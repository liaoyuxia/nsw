package com.nsw.wx.plat.order.service;

import com.nsw.wx.plat.order.pojo.User;

public interface TestService {
    public Object  add(User user);
}
