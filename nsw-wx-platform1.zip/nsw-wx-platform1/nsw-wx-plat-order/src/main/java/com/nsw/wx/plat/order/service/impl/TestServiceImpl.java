package com.nsw.wx.plat.order.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsw.wx.plat.order.pojo.User;
import com.nsw.wx.plat.order.service.DrawClient;
import com.nsw.wx.plat.order.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements TestService {
    @Autowired
    private DrawClient drawClient;
    @Override
    public Object add(User user) {
        return drawClient.nb(user);
    }
}
