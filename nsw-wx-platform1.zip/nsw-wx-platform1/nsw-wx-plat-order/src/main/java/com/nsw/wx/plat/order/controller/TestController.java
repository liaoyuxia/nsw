package com.nsw.wx.plat.order.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.nsw.wx.plat.order.pojo.User;
import com.nsw.wx.plat.order.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/order")
public class TestController {
    @Autowired
    private TestService testService;
    @ResponseBody
    @RequestMapping("/test")
    public Object testCont(){
        System.out.println("============");
        User user = new User();
        user.setPassword("121");
        user.setPhone("1212");
        user.setUserId(4);
        user.setUserName("ghjfetjekt");
        //String userJson = JSON.toJSONString(user);
        //String userJson = JSON.toJSONString(user, SerializerFeature.WriteClassName);
        return user;
    }
}
