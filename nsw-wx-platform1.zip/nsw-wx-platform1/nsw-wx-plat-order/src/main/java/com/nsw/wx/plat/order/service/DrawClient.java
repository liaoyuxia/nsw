package com.nsw.wx.plat.order.service;

import com.nsw.wx.plat.order.pojo.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 * 商品服务客户端
 */
@FeignClient(name = "plat-draw-service")
public interface DrawClient {


//    @GetMapping("/api/test/add")
    @RequestMapping(value ="/api/test/add",method = RequestMethod.GET,consumes = "application/json")
    int nb(@RequestBody User user);


}
