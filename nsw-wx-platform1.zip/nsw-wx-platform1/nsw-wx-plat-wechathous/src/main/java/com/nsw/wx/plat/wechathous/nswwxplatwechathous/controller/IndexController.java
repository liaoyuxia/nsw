package com.nsw.wx.plat.wechathous.nswwxplatwechathous.controller;


import com.nsw.wx.plat.wechathous.nswwxplatwechathous.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/wx")
public class IndexController {

    @Autowired
    private UserService userService;
    @RequestMapping("aaaa")
    public Object index() {

        return userService.findAll();
    }
}
