package com.nsw.wx.plat.wechathous.nswwxplatwechathous;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
@MapperScan("com.nsw.wx.plat.wechathous.nswwxplatwechathous.mapper")
@SpringBootApplication
//@EnableEurekaClient
public class NswWxPlatWechathousApplication {

    public static void main(String[] args) {
        SpringApplication.run(NswWxPlatWechathousApplication.class, args);
    }
}
