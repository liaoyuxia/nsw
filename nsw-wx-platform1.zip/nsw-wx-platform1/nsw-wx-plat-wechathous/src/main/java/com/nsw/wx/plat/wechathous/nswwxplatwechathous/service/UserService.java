package com.nsw.wx.plat.wechathous.nswwxplatwechathous.service;

import com.nsw.wx.plat.wechathous.nswwxplatwechathous.pojo.User;

import java.util.List;

public interface UserService {
    List<User> findAll();
}
