package com.nsw.wx.plat.wechathous.nswwxplatwechathous.mapper;

import com.nsw.wx.plat.wechathous.nswwxplatwechathous.pojo.User;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserMapper {
    @Select("select * from t_user")
    List<User> findAll();
}
