package com.nsw.wx.plat.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class NswWxPlatProductApplication {

    public static void main(String[] args) {
        SpringApplication.run(NswWxPlatProductApplication.class, args);
    }
}
