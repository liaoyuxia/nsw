package com.nsw.wx.plat.draw;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

//@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)

//@MapperScan("com.nsw.wx.plat.draw.mapper")
//@SpringBootApplication
//@MapperScan("com.nsw.wx.plat.draw.mapper")
//
////@EnableEurekaClient

@MapperScan("com.nsw.wx.plat.draw.mapper")
@SpringBootApplication
public class NswWxPlatDrawApplication {

    public static void main(String[] args) {
        SpringApplication.run(NswWxPlatDrawApplication.class, args);
    }
}
