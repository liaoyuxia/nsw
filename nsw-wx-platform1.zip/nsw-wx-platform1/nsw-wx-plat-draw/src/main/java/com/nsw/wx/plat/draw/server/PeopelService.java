package com.nsw.wx.plat.draw.server;

import com.nsw.wx.plat.draw.mapper.PeopleMapper;
import com.nsw.wx.plat.draw.pojo.People;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PeopelService {
	@Autowired
	private PeopleMapper peopleMapper;

	//	查询全部
	public List<People> listAll(){
		return peopleMapper.selectAll();
		
	}
	//插入	
	public int add(People people) {
		return peopleMapper.add(people);
	}

	//更新
	public int Update(People people){
		return peopleMapper.update(people);
	}

	//删除
	public int Del(People people){
		return peopleMapper.Del(people);
	}
}
