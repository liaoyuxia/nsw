package com.nsw.wx.plat.draw.mapper;


import com.nsw.wx.plat.draw.pojo.User;
import com.nsw.wx.plat.draw.query.UserQueryObject;

import java.util.List;

public interface UserMapper {
    int deleteByPrimaryKey(Integer userId);

    int insert(User record);
    List<User> queryAll();

   int delectTest(int user_id);


}