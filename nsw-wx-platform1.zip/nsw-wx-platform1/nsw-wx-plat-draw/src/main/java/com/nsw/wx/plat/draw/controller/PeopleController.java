package com.nsw.wx.plat.draw.controller;

import com.nsw.wx.plat.draw.pojo.People;
import com.nsw.wx.plat.draw.server.PeopelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("people")
public class PeopleController {
    @Autowired
    private PeopelService peopelService;

    @GetMapping("/listAll")
    public List<People> listAll2(){
        return peopelService.listAll();
    }

    @GetMapping("/insert")
    public int insert(){
        People people = new People();
        people.setName("周权");
        people.setAge(18);
        people.setSex("男");
        people.setAddress("邵阳");
        return peopelService.add(people);
    }
    @GetMapping("/update")
    public int Update() {
        People people = new People();
        people.setName("找那个三");
        people.setId(2);
        return peopelService.Update(people);
    }

    @GetMapping("/delete")
    public int Del(){
        People people = new People();
        people.setId(2);
        return peopelService.Del(people);
    }

}
