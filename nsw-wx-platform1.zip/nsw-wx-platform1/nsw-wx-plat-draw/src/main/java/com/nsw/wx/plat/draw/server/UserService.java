package com.nsw.wx.plat.draw.server;

import com.github.pagehelper.PageInfo;
import com.nsw.wx.plat.draw.pojo.User;
import com.nsw.wx.plat.draw.query.UserQueryObject;

import java.util.List;

public interface UserService {
    int addUser(User user);

    PageInfo<User> pageSelect(int page, int pageSize);


    List<User>getAll();

    int delectTest(int user_id);

}
