package com.nsw.wx.plat.draw.mapper;

import com.nsw.wx.plat.draw.pojo.People;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PeopleMapper {
    @Select("select * from people")
    List<People> selectAll();

    @Insert("INSERT into people(name,age,sex,address) VALUES(#{name},#{age},#{sex},#{address})")
    int add(People people);

    @Update("UPDATE people SET name=#{name} WHERE id =#{id}")
    int update(People people);

    @Delete("DELETE FROM people WHERE id =#{id}")
    int Del(People people);
}
