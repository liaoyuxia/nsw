package com.nsw.wx.plat.draw.controller;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageInfo;
import com.nsw.wx.plat.draw.pojo.User;
import com.nsw.wx.plat.draw.server.UserService;
import com.nsw.wx.plat.draw.util.JsonData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/api/test")
public class UserController {
    @Autowired
    private UserService userService;
    @ResponseBody
    @RequestMapping(value = "/add")
    public  int nb(HttpServletRequest request,HttpServletResponse response){
        response.setHeader("Access-Control-Allow-Origin", "*");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");
        String userName = request.getParameter("userName");

        User user  = new User();
        user.setPhone(phone);
        user.setPassword(password);
        user.setUserName(userName);
        return userService.addUser(user);
    }


    @RequestMapping("/index")
    @ResponseBody
    public Object index(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        int page = Integer.parseInt(request.getParameter("page"));
        int pageSize = Integer.parseInt(request.getParameter("limit"));
        System.out.println(page);
        System.out.println(pageSize);

        PageInfo<User> pageInfoList = userService.pageSelect(page, pageSize);

        List<User> list = pageInfoList.getList();
        long count=pageInfoList.getTotal();

        String json = JSONArray.toJSONString(list);
        return JsonData.buildSuccess(count,list);
    }



    @RequestMapping("/index1")
    @ResponseBody
    public Object list1(HttpServletRequest request, HttpServletResponse response){
       response.setHeader("Access-Control-Allow-Origin","*");
        int user_id = Integer.parseInt(request.getParameter("user_id"));

      return userService.delectTest(user_id);
    }

}
